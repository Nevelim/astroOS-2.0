/**
 * POST /api/local-space — Local Space chart (planetary lines on local horizon).
 * Projects planetary positions onto the local horizontal coordinate system.
 * Each planet gets an azimuth (compass direction) + altitude.
 * Clean Architecture: uses astronomy-engine via loadEngine.
 */
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { loadEngine } from "@/infrastructure/external-services/astronomy/AstronomyEngineChartCalculator";

const Schema = z.object({
  birthDateTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/),
  birthLat: z.number().min(-90).max(90),
  birthLng: z.number().min(-180).max(180),
  birthTzOffset: z.number().min(-14).max(14),
});

const PLANETS = ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto"];

const PLANET_COLORS: Record<string, string> = {
  Sun: "#FBBF24", Moon: "#94A3B8", Mercury: "#60A5FA", Venus: "#F472B6",
  Mars: "#EF4444", Jupiter: "#A78BFA", Saturn: "#94A3B8",
  Uranus: "#22D3EE", Neptune: "#2DD4BF", Pluto: "#9333EA",
};

const PLANET_GLYPHS: Record<string, string> = {
  Sun: "☉", Moon: "☾", Mercury: "☿", Venus: "♀", Mars: "♂",
  Jupiter: "♃", Saturn: "♄", Uranus: "♅", Neptune: "♆", Pluto: "♇",
};

const COMPASS_SECTORS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];

function azimuthToSector(az: number): string {
  const idx = Math.round((((az % 360) + 360) % 360) / 22.5) % 16;
  return COMPASS_SECTORS[idx];
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = Schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input", details: parsed.error.flatten() }, { status: 400 });
    }
    const data = parsed.data;

    const Astro = await loadEngine();
    const localDate = new Date(data.birthDateTime + "Z");
    const utcDate = new Date(localDate.getTime() - data.birthTzOffset * 3600000);

    // Horizontal coordinates for each planet
    const Body = (Astro as { Body: Record<string, unknown> }).Body;
    const Equator = (Astro as { Equator: (body: unknown, date: Date, observer: unknown, ofdate: boolean, aberration: boolean) => { lon: number; lat: number } }).Equator;
    const Observer = (Astro as { Observer: new (lat: number, lng: number, height: number) => unknown }).Observer;
    const observer = new Observer(data.birthLat, data.birthLng, 0);

    const planetLines = PLANETS.map((planet) => {
      try {
        const body = Body[planet];
        if (!body) return null;

        const equ = Equator(body, utcDate, observer, false, false) as { ra: number; dec: number };
        // ra is in hours, convert to degrees
        const lonDeg = ((equ.ra * 15) + 360) % 360;
        const latDeg = equ.dec;

        // Simplified azimuth: project ecliptic longitude onto local horizon
        const lstDeg = ((utcDate.getUTCHours() + data.birthTzOffset) * 15 + data.birthLng) % 360;
        const azimuthDeg = (lonDeg - lstDeg + 360) % 360;

        // Simplified altitude
        const latRad = (data.birthLat * Math.PI) / 180;
        const decRad = (latDeg * Math.PI) / 180; // latDeg (dec) is in degrees
        const haRad = ((azimuthDeg - 180) * Math.PI) / 180;
        const sinAlt = Math.sin(decRad) * Math.sin(latRad) + Math.cos(decRad) * Math.cos(latRad) * Math.cos(haRad);
        const altRad = Math.asin(Math.max(-1, Math.min(1, sinAlt)));
        const altitudeDeg = (altRad * 180) / Math.PI;

        return {
          planet,
          glyph: PLANET_GLYPHS[planet],
          color: PLANET_COLORS[planet],
          azimuth: Math.round(azimuthDeg * 10) / 10,
          altitude: Math.round(altitudeDeg * 10) / 10,
          sector: azimuthToSector(azimuthDeg),
          above: altitudeDeg > 0,
        };
      } catch (e) {
        console.error(`[local-space] ${planet} error:`, (e as Error).message);
        return null;
      }
    }).filter((p): p is NonNullable<typeof p> => p !== null);

    // Group by sector for visualization
    const sectors = COMPASS_SECTORS.map((sector) => ({
      sector,
      planets: planetLines.filter((p) => p.sector === sector),
    })).filter((s) => s.planets.length > 0);

    return NextResponse.json({
      birth: {
        lat: data.birthLat,
        lng: data.birthLng,
        placeName: "Birthplace",
      },
      planetLines,
      sectors,
      totalAbove: planetLines.filter((p) => p.above).length,
      totalBelow: planetLines.filter((p) => !p.above).length,
    });
  } catch (error) {
    console.error("[local-space] error:", error);
    return NextResponse.json({ error: "Local space failed", message: (error as Error).message }, { status: 500 });
  }
}
