"use client";

import {
  GlassCard, Pill, CosmicButton, SectionHeading, FadeIn, CosmicDivider,
} from "../ui";
import { InfoTip } from "../growth-ui";
import { useI18n } from "@/lib/astroos/i18n-context";
import { LOCAL_SPACE, PLANETS } from "@/lib/astroos/data";
import { localized } from "@/lib/astroos/data";
import { RealLocalSpacePanel } from "../real/RealLocalSpacePanel";

export function LocalSpaceScreen() {
  const { t, locale } = useI18n();
  const ls = LOCAL_SPACE;
  const planetColor = (name: string) => PLANETS.find((p) => p.key === name)?.color ?? "#9A9AA8";

  return (
    <div className="space-y-10">
      <FadeIn>
        <SectionHeading
          eyebrow={t("local.eyebrow")}
          title={t("local.title")}
          subtitle={t("local.subtitle")}
        />
      </FadeIn>

      {/* Real local space compass — astronomy-engine horizontal coordinates */}
      <FadeIn delay={0.03}>
        <RealLocalSpacePanel locale={locale} />
      </FadeIn>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* SVG wheel — 8 sectors with rays */}
        <FadeIn delay={0.05}>
          <GlassCard variant="gold" className="h-full">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Pill tone="gold">{t("local.sectors")}</Pill>
                <InfoTip
                  label={locale === "ru" ? "Local Space (локальное пространство)" : locale === "hi" ? "Local Space" : "Local Space"}
                  tone="gold"
                  side="bottom"
                >
                  {locale === "ru"
                    ? "Local Space — древняя техника: ваша натальная карта проецируется на план квартиры/дома. Каждая планета «ложится» в свой сектор (N, NE, E, SE, S, SW, W, NW). Где спать, работать, ставить дверь — зависит от того, какие планеты в каком секторе."
                    : locale === "hi"
                    ? "Local Space — आपकी नेटल चार्ट आपके घर के नक्शे पर। हर ग्रह एक दिशा में।"
                    : "Local Space — an ancient technique: your natal chart projected onto your home's floor plan. Each planet 'lands' in a directional sector (N, NE, E, ...). Where to sleep, work, place the door depends on which planets sit in which sector."}
                </InfoTip>
              </span>
              <Pill tone="muted">0° = N · 90° = E</Pill>
            </div>
            <div className="mt-4 flex justify-center">
              <svg viewBox="0 0 360 360" className="h-auto w-full max-w-[380px]">
                <defs>
                  <radialGradient id="lsBg" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#1C1C26" />
                    <stop offset="100%" stopColor="#0B0B0F" />
                  </radialGradient>
                </defs>
                <circle cx="180" cy="180" r="170" fill="url(#lsBg)" stroke="#2A2A35" strokeWidth="1" />
                <circle cx="180" cy="180" r="130" fill="none" stroke="#2A2A35" strokeWidth="0.5" />
                <circle cx="180" cy="180" r="90" fill="none" stroke="#2A2A35" strokeWidth="0.5" />
                {/* 8 sector lines (every 45°) */}
                {Array.from({ length: 8 }).map((_, i) => {
                  const a = (i * 45 - 90) * Math.PI / 180;
                  return (
                    <line key={i} x1="180" y1="180"
                      x2={180 + 170 * Math.cos(a)} y2={180 + 170 * Math.sin(a)}
                      stroke="#2A2A35" strokeWidth="1" />
                  );
                })}
                {/* Sector fills (color by tone) */}
                {ls.sectors.map((s) => {
                  const startA = (s.deg - 22.5 - 90) * Math.PI / 180;
                  const endA = (s.deg + 22.5 - 90) * Math.PI / 180;
                  const x1 = 180 + 170 * Math.cos(startA);
                  const y1 = 180 + 170 * Math.sin(startA);
                  const x2 = 180 + 170 * Math.cos(endA);
                  const y2 = 180 + 170 * Math.sin(endA);
                  const color = s.tone === "gold" ? "#E8B86D" : s.tone === "jade" ? "#5BB89C" : s.tone === "rose" ? "#D98E7A" : s.tone === "water" ? "#5E8FA8" : "#9A9AA8";
                  return (
                    <path key={s.dir} d={`M180,180 L${x1},${y1} A170,170 0 0,1 ${x2},${y2} Z`}
                      fill={color} opacity={s.planets.length > 0 ? 0.12 : 0.03} stroke={color} strokeWidth="0.5" strokeOpacity="0.3" />
                  );
                })}
                {/* Direction labels */}
                {ls.sectors.map((s) => {
                  const a = (s.deg - 90) * Math.PI / 180;
                  const color = s.tone === "gold" ? "#E8B86D" : s.tone === "jade" ? "#5BB89C" : s.tone === "rose" ? "#D98E7A" : s.tone === "water" ? "#5E8FA8" : "#6B6B78";
                  return (
                    <text key={s.dir} x={180 + 150 * Math.cos(a)} y={180 + 150 * Math.sin(a) + 4}
                      fill={color} fontSize="11" fontWeight="bold" textAnchor="middle">{s.dir}</text>
                  );
                })}
                {/* Planet rays from center */}
                {ls.sectors.filter((s) => s.planets.length > 0).flatMap((s) =>
                  s.planets.map((pname) => {
                    const planet = PLANETS.find((p) => p.key === pname);
                    const a = (s.deg - 90) * Math.PI / 180;
                    const endX = 180 + 165 * Math.cos(a);
                    const endY = 180 + 165 * Math.sin(a);
                    return (
                      <g key={`${s.dir}-${pname}`}>
                        <line x1="180" y1="180" x2={endX} y2={endY} stroke={planet?.color} strokeWidth="1.5" opacity="0.6" />
                        <circle cx={endX} cy={endY} r="11" fill={planet?.color} />
                        <text x={endX} y={endY + 4} fill="#0B0B0F" fontSize="11" textAnchor="middle" fontWeight="bold">{planet?.symbol}</text>
                      </g>
                    );
                  })
                )}
                {/* Center (your home) */}
                <circle cx="180" cy="180" r="6" fill="#E8B86D" />
                <text x="180" y="184" fill="#0B0B0F" fontSize="8" textAnchor="middle" fontWeight="bold">⌂</text>
              </svg>
            </div>
          </GlassCard>
        </FadeIn>

        {/* Sector recommendations table */}
        <FadeIn delay={0.1}>
          <GlassCard className="h-full">
            <Pill tone="jade">{t("local.recommendations")}</Pill>
            <div className="mt-3 space-y-1.5">
              {ls.sectors.map((s) => {
                const color = s.tone === "gold" ? "#E8B86D" : s.tone === "jade" ? "#5BB89C" : s.tone === "rose" ? "#D98E7A" : s.tone === "water" ? "#5E8FA8" : "#6B6B78";
                return (
                  <div key={s.dir} className="flex items-start gap-2 rounded-lg border border-[#2A2A35] bg-[#0B0B0F]/40 p-2">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded font-display text-sm font-bold" style={{ color, border: `1px solid ${color}40` }}>
                      {s.dir}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] text-[#9A9AA8]">{s.deg}°</span>
                        {s.planets.length > 0 ? s.planets.map((p) => {
                          const pl = PLANETS.find((x) => x.key === p);
                          return <Pill key={p} tone={s.tone}>{pl?.symbol} {p}</Pill>;
                        }) : <span className="text-[10px] text-[#6B6B78]">— empty</span>}
                      </div>
                      <div className="mt-0.5 text-[11px] text-[#F5F0E8]/80">{localized(locale, s.rec)}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </GlassCard>
        </FadeIn>
      </div>

      <CosmicDivider />

      {/* Home recommendations cards */}
      <FadeIn delay={0.15}>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <GlassCard variant="jade">
            <div className="text-2xl">🛏️</div>
            <div className="mt-1 text-[10px] uppercase tracking-wider text-[#9A9AA8]">{t("local.bed")}</div>
            <div className="mt-1 font-display text-xl text-[#5BB89C]">{ls.recommendations.bed.dir}</div>
            <p className="mt-1 text-[11px] text-[#9A9AA8]">{localized(locale, ls.recommendations.bed.why)}</p>
          </GlassCard>
          <GlassCard variant="gold">
            <div className="text-2xl">💼</div>
            <div className="mt-1 text-[10px] uppercase tracking-wider text-[#9A9AA8]">{t("local.workspace")}</div>
            <div className="mt-1 font-display text-xl text-[#E8B86D]">{ls.recommendations.workspace.dir}</div>
            <p className="mt-1 text-[11px] text-[#9A9AA8]">{localized(locale, ls.recommendations.workspace.why)}</p>
          </GlassCard>
          <GlassCard variant="rose">
            <div className="text-2xl">🚪</div>
            <div className="mt-1 text-[10px] uppercase tracking-wider text-[#9A9AA8]">{t("local.door")}</div>
            <div className="mt-1 font-display text-xl text-[#D98E7A]">{ls.recommendations.door.dir}</div>
            <p className="mt-1 text-[11px] text-[#9A9AA8]">{localized(locale, ls.recommendations.door.why)}</p>
          </GlassCard>
          <GlassCard>
            <div className="text-2xl">⚠️</div>
            <div className="mt-1 text-[10px] uppercase tracking-wider text-[#9A9AA8]">{t("local.avoid")}</div>
            <div className="mt-1 font-display text-xl text-[#9A9AA8]">{ls.recommendations.avoid.dir}</div>
            <p className="mt-1 text-[11px] text-[#9A9AA8]">{localized(locale, ls.recommendations.avoid.why)}</p>
          </GlassCard>
        </div>
      </FadeIn>

      <FadeIn delay={0.2}>
        <GlassCard variant="gold">
          <Pill tone="gold">✨ {t("local.energy")}</Pill>
          <p className="mt-3 text-[14px] leading-relaxed text-[#F5F0E8]/90">{localized(locale, ls.recommendations.energy)}</p>
        </GlassCard>
      </FadeIn>
    </div>
  );
}
